package com.ahom.hrms.Repository;

import com.ahom.hrms.entities.EmployeeAllowances;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeAllowancesRepository extends JpaRepository<EmployeeAllowances, Integer> {

}
