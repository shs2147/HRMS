package com.ahom.hrms.Repository;

import com.ahom.hrms.entities.Interview;
import org.springframework.data.jpa.repository.JpaRepository;


public interface InterviewRepo extends JpaRepository<Interview, Integer>{

}
