package com.ahom.hrms.Repository;


import com.ahom.hrms.entities.LeaveType;
import org.springframework.data.jpa.repository.JpaRepository;



public interface LeaveTypeRepository extends JpaRepository<LeaveType,Integer> {

}
