package com.ahom.hrms.Repository;

import com.ahom.hrms.entities.EmployeeDeduction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeDeductionRepository extends JpaRepository<EmployeeDeduction, Integer>{

}
