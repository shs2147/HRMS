package com.ahom.hrms.Repository;

import com.ahom.hrms.entities.Deduction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DeductionRepository extends JpaRepository<Deduction, Integer> {

}
