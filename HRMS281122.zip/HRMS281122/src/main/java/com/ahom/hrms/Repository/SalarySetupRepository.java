package com.ahom.hrms.Repository;

import com.ahom.hrms.entities.SalarySetup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalarySetupRepository extends JpaRepository<SalarySetup,Integer> {
}
