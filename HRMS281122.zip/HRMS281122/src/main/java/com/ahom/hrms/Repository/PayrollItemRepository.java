package com.ahom.hrms.Repository;


import com.ahom.hrms.entities.Payroll_Item;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PayrollItemRepository extends JpaRepository <Payroll_Item, Integer>{
		


	}
	
